#include <cstdint>
#include <cstdio>
#include <csignal>
#include <cstring>
#include <fcntl.h>
#include <atomic>
#include <string>
#include <sys/stat.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <iostream>
#include <unistd.h>
#include <linux/gpio.h>
#include <fstream>
#include "Sequencer.hpp"

std::atomic<bool> _runningstate{true};
bool pinstateGPIO4 = 1;
int togglingMethodGlobal =0;

constexpr int GPIO_PIN_TO_TOGGLE = 4;
constexpr int GPIOCHIP0_BASE = 512;
constexpr std::uintptr_t GPIO_BASE = 0xFE200000; // GPIO base address for Raspberry Pi 4 (BCM2711)
constexpr std::size_t GPIO_SIZE = 0xB0;          // Size of GPIO register block
constexpr std::uintptr_t GPFSEL0 = 0x00;         // Function select register 0
constexpr std::uintptr_t GPSET0 = 0x1C;          // Set register 0
constexpr std::uintptr_t GPCLR0 = 0x28;          // Clear register 0

volatile std::uint32_t *gpio=NULL;
enum class toggleMethod{
    PINCTRL=1,
    SYSFS,
    IOCTL,
    MMAP
};
void signalHandler(int signum)
{
    std::puts("\nReceived Ctrl+C, stopping services ");
    _runningstate.store(false, std::memory_order_relaxed);
    if(togglingMethodGlobal==static_cast<int>(toggleMethod::SYSFS))
    {
        //Unexport sysfs entry and then exit
            //If sysfs entry is already present then the entry should be unexported
        int sysfsPin = GPIOCHIP0_BASE+GPIO_PIN_TO_TOGGLE;
        std::string basePath = "/sys/class/gpio/gpio"+std::to_string(sysfsPin);
        struct stat buffer;
        //If the directory is present then unexport and then issue ioctl commands as GPIO is already in use
        if(stat(basePath.c_str(),&buffer)==0)
        {
            std::puts("Removing sysfs entry");
            std::ofstream unexportFile("/sys/class/gpio/unexport");
            unexportFile << sysfsPin;
            unexportFile.close();
        }

    }
    
}

void toggleGPIOPinctrl(int pin,bool pinstate)
{
    std::string setHigh = "pinctrl set "+std::to_string(pin)+" op dh";
    std::string setLow = "pinctrl set "+std::to_string(pin)+" op dl";
    if(pinstate)
    {
        system(setHigh.c_str());
    }
    else
    {
        system(setLow.c_str());
    }
}


void toggleGPIOSysfs(int pin,bool pinstate)
{
    int sysfsPin = GPIOCHIP0_BASE+pin;
    std::string basePath = "/sys/class/gpio/gpio"+std::to_string(sysfsPin);
    std::string directionPath = basePath + "/direction";
    std::string valuePath = basePath + "/value";
     //Check if gpiobase(lowest)+pin number  is present in /sys/class/gpio is present
     struct stat buffer;
    if(stat(basePath.c_str(),&buffer)!=0)
    {
        std::ofstream exportFile("/sys/class/gpio/export");
        exportFile << sysfsPin;
        exportFile.close();
        //Set pin direction to ouput
        std::ofstream directionFile(directionPath);
        directionFile << "out";
        directionFile.close();

    }
    //If present directly toggle the pin
    std::ofstream valueFile(valuePath);
    valueFile << (pinstate?"1":"0");
    valueFile.close();
}
void toggleGPIOIoctl(int pin,bool pinstate)
{
    //If sysfs entry is already present then the entry should be unexported
    int sysfsPin = GPIOCHIP0_BASE+pin;
    std::string basePath = "/sys/class/gpio/gpio"+std::to_string(sysfsPin);
    struct stat buffer;
    //If the directory is present then unexport and then issue ioctl commands as GPIO is already in use
    if(stat(basePath.c_str(),&buffer)==0)
    {
        std::ofstream unexportFile("/sys/class/gpio/unexport");
        unexportFile << sysfsPin;
        unexportFile.close();
    }
    int fd=open("/dev/gpiochip0",O_RDWR);
    if(fd<0)
    {
        std::puts("Failed to open gpiochip0");
        return;
    }
    struct gpiohandle_request req;
    memset(&req, 0, sizeof(req));
    req.lineoffsets[0] = pin;
    req.flags = GPIOHANDLE_REQUEST_OUTPUT;
    req.default_values[0] = pinstate ? 1 : 0;
    req.lines = 1;
    strcpy(req.consumer_label, "ioctl_toggling");
    if(ioctl(fd,GPIO_GET_LINEHANDLE_IOCTL,&req)==-1)
    {
        std::puts("Failed to get line handle ioctl");
        close(fd);
        return;
    }

    struct gpiohandle_data data;
    memset(&data, 0, sizeof(data));
    data.values[0] = (pinstate)?1:0;
    if(ioctl(req.fd,GPIOHANDLE_SET_LINE_VALUES_IOCTL,&data)==-1)
    {
        std::puts("Failed to set GPIO value");
    }
    close(req.fd);
    close(fd);
}

void initializeGPIOMmap(int pin)
{
    //Reference: https://www.codeembedded.com/blog/raspberry_pi_gpio/
    int memFd;
    void *gpioMap;
    if((memFd = open("/dev/mem",O_RDWR|O_SYNC))<0)
    {
        std::puts("Failed to open /dev/mem");
        return;
    }
    gpioMap = mmap(NULL,GPIO_SIZE,PROT_READ |PROT_WRITE,MAP_SHARED,memFd,GPIO_BASE);
    if(gpioMap == MAP_FAILED)
    {
        std::puts("Mmap Failed");
        close(memFd);
        return;
    }
    gpio = (volatile uint32_t*)gpioMap;
    //Set GPIO pin as output
    //GPIOSEL0 goes from 0-9 and GPIOSEL1 goes from 10-19 and so on
    int reg = pin/10;
    int shift = (pin%10)*3;
    if(gpio!=NULL)
    {
        gpio[reg] = (gpio[reg] & ~(7 << shift)) | (1 << shift);
    }
    close(memFd);
}
void toggleGPIOMmap(int pin,bool pinstate)
{
    if(pinstate)
    {
        gpio[GPSET0 / 4] = 1 << pin;
    }
    else
    {
        gpio[GPCLR0 / 4] = 1 << pin;
    }
}



int main(int argc, char* argv[])
{
    std::signal(SIGINT, signalHandler);
    
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <method_number>\n"
                  << "Where <method_number> corresponds to the desired GPIO toggling method:\n"
                  << "  1: Toggle using Pinctrl\n"
                  << "  2: Toggle using Sysfs\n"
                  << "  3: Toggle using Ioctl\n"
                  << "  4: Toggle using Mmap\n";
        return 1;
    }

    int togglingMethod = std::stoi(argv[1]);
    togglingMethodGlobal = togglingMethod;
    if (togglingMethod < 1 || togglingMethod > 4) {
        std::cerr << "Invalid input. Please enter 1 (Pinctrl), 2 (Sysfs), 3 (Ioctl), or 4 (Mmap).\n";
        return 1;
    }
    Sequencer sequencer{};
    if(togglingMethod==static_cast<int>(toggleMethod::MMAP))
    {
        initializeGPIOMmap(GPIO_PIN_TO_TOGGLE);
    }
    
    //Lambda function for toggling the pin based on the input received
    auto togglePin = [togglingMethod]() {
        pinstateGPIO4 = !pinstateGPIO4;
        switch (togglingMethod) {
            case 1:
                //std::puts("Toggling using PINCTRL");
                toggleGPIOPinctrl(4, pinstateGPIO4);
                break;
            case 2:
                //std::puts("Toggling using SYSFS");
                toggleGPIOSysfs(4, pinstateGPIO4);
                break;
            case 3:
                //std::puts("Toggling using IOCTL");
                toggleGPIOIoctl(4, pinstateGPIO4);
                break;
            case 4:
                //std::puts("Toggling using MMAP");
                toggleGPIOMmap(4, pinstateGPIO4);
                break;
        }
    };
    sequencer.addService(togglePin, 1, 99, 100);

    sequencer.startServices();
    while (_runningstate.load(std::memory_order_relaxed))
    {
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    sequencer.stopServices();
    return 0;
}